<?php include('includes/header.php'); ?>


<?php
function spamcheck($field)
{
	  //filter_var() sanitizes the e-mail
	  //address using FILTER_SANITIZE_EMAIL
	  $field=filter_var($field, FILTER_SANITIZE_EMAIL);

	  //filter_var() validates the e-mail
	  //address using FILTER_VALIDATE_EMAIL
		  if(filter_var($field, FILTER_VALIDATE_EMAIL))
			{
			return TRUE;
			}
		  else
			{
			return FALSE;
			}
}


if (isset($_REQUEST['submit']))
  {
	//if "email" is filled out, proceed
	//check if the email address is invalid
	  $mailcheck = spamcheck($_REQUEST['email']);
	  if ($mailcheck==FALSE)
			{
				echo "<script>alert (\"Email Spam\")</script>";
			}
	  else
			{
				//send email
				$name = $_REQUEST['name'] ;
				$email = $_REQUEST['email'] ;
				$website = $_REQUEST['website'] ;
				mail("msmjsuarez@gmail.com", "Subject: FashionSponge - Sign Up For Beta",
				"From: $name", "Email: $email", "Website: $website" );
				?>
			
                <div id="overlay_form">
                    <p>
                        <center><img src="images/fashion-sponge-logo.png" /></center>
                        Hi <?php echo $name; ?>,
                        <br /><br />
                        Thank you for signing up for an invitation to FashionSponge!
                        We appreciate your interest. Our designers and developers are 
                        hard at work to bring you the best experience possible. <br /><br />
                        
                        Check your email for a welcome message, and make sure to 
                        follow our social pages for more information about our community.<br /><br />
                        
                        Thanks, <br />
                        Salvador Mussolini
                    </p>
                        <a href="#" id="close" >Close</a>
                </div>
				
				<?php	
			}
}
?>


<div id="content">

<h2>The Easiest and Fastest Way To...</h2>

<div class="arrow"></div>

<div class="colcontainer">
	<div class="col1">
        <p><img src="images/share-icon.png" width="120" style="margin:auto;"/></p>
        <h3>SHARE</h3>
        <p>Fashion & Lifestyle Photos</p>
        <p>Daily Outfits</p>
        <p>Blog Posts</p>
   </div>
   <div class="col2">
    	<p><img src="images/discover-icon.png" width="120" /></p>
        <h3>DISCOVER</h3>
        <p>Fashionable People</p>
        <p>Brands & Botiques</p>
        <p>New Blogs</p>
   </div>
	<div class="col3">
        <p><img src="images/learn-icon.png" width="120" /></p>
        <h3>LEARN</h3>
        <p>Get Beauty/Grooming Tips</p>
        <p>Get Style Advise</p>
        <p>Get News</p>
    </div>
	<div class="col4">
        <p><img src="images/rewards-icon.png" width="120" /></p>
        <h3>REWARDS</h3>
        <p>Get Featured</p>
        <p>Win Prizes</p>
        <p>Win Cash</p>
    </div>
</div>    
    
<div style="clear:both;"></div>


</div> <!-- end #content -->

<?php include('includes/footer.php'); ?>

		</div> <!-- End #wrapper -->

	</body>

</html>
