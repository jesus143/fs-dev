<?php
$heading='';
$footer='Copyright &copy; 2013 FashionSponge';
?>
